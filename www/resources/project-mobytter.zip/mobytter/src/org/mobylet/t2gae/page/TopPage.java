package org.mobylet.t2gae.page;

import java.util.ArrayList;
import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.Query;

import org.mobylet.t2gae.dto.CommentDto;
import org.mobylet.t2gae.util.PMF;
import org.t2framework.commons.annotation.composite.SingletonScope;
import org.t2framework.t2.annotation.core.Default;
import org.t2framework.t2.annotation.core.Page;
import org.t2framework.t2.contexts.WebContext;
import org.t2framework.t2.navigation.Forward;
import org.t2framework.t2.spi.Navigation;

@SingletonScope
@Page("/top")
public class TopPage {

	@Default
	@SuppressWarnings("unchecked")
	public Navigation index(WebContext context) {
		PersistenceManager pm = PMF.get().getPersistenceManager();
		try {
			Query query = pm.newQuery(CommentDto.class);
			query.setOrdering("postDate desc");
			query.setRange(0, 30);

			List<CommentDto> commentList =
				(List<CommentDto>)query.execute();

			List<String> commentStrList = new ArrayList<String>();
			for (CommentDto commentObj : commentList) {
				commentStrList.add(commentObj.getComment());
			}

			context.getRequest().setAttribute("list", commentStrList);
		} finally {
			pm.close();
		}

		return Forward.to("/WEB-INF/view/index.jsp");
	}

}
