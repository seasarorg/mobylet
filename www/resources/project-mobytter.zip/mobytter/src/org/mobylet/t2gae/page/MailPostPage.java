package org.mobylet.t2gae.page;

import java.util.Date;

import javax.jdo.PersistenceManager;

import org.mobylet.core.util.StringUtils;
import org.mobylet.t2gae.dto.CommentDto;
import org.mobylet.t2gae.util.PMF;
import org.t2framework.commons.annotation.composite.SingletonScope;
import org.t2framework.t2.annotation.core.Default;
import org.t2framework.t2.annotation.core.Page;
import org.t2framework.t2.contexts.Request;
import org.t2framework.t2.contexts.WebContext;
import org.t2framework.t2.navigation.Redirect;
import org.t2framework.t2.spi.Navigation;

@SingletonScope
@Page("/mailpost")
public class MailPostPage {

	@Default
	public Navigation index(WebContext context) {
		Request request = context.getRequest();
		String comment = request.getParameter("pBody");

		if (StringUtils.isEmpty(comment)) {
			return Redirect.to("/top");
		}

		CommentDto dto = new CommentDto();
		dto.setComment(comment + "(MAIL)");
		dto.setPostDate(new Date());

		PersistenceManager pm = PMF.get().getPersistenceManager();
		try {
			pm.makePersistent(dto);
		} finally {
			pm.close();
		}

		return Redirect.to("/top");
	}

}
