package org.mobylet.t2gae.page;

import java.util.Date;

import javax.jdo.PersistenceManager;

import org.mobylet.core.Mobylet;
import org.mobylet.core.util.StringUtils;
import org.mobylet.t2gae.dto.CommentDto;
import org.mobylet.t2gae.util.PMF;
import org.t2framework.commons.annotation.composite.RequestScope;
import org.t2framework.t2.annotation.core.Default;
import org.t2framework.t2.annotation.core.Page;
import org.t2framework.t2.contexts.Request;
import org.t2framework.t2.contexts.WebContext;
import org.t2framework.t2.navigation.Redirect;
import org.t2framework.t2.spi.Navigation;

import com.google.inject.Inject;

@RequestScope
@Page("/post")
public class PostPage {

	@Inject
	protected Mobylet mobylet;

	@Default
	public Navigation index(WebContext context) {
		Request request = context.getRequest();
		String comment = request.getParameter("comment");

		if (StringUtils.isEmpty(comment)) {
			return Redirect.to("/top");
		}

		CommentDto dto = new CommentDto();
		dto.setComment(comment + "(" + mobylet.getCarrier() + ")");
		dto.setPostDate(new Date());

		PersistenceManager pm = PMF.get().getPersistenceManager();
		try {
			pm.makePersistent(dto);
		} finally {
			pm.close();
		}

		return Redirect.to("/top");
	}

}
